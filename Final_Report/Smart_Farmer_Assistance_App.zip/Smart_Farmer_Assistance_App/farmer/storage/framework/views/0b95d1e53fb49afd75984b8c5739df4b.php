<div class="jumbotron" style="background-image: url('<?php echo e($backgroundImage); ?>'); background-size: cover; background-position: center; height: 80vh;">
    <div class="row" style="background: rgba(0, 0, 0, 0.5); padding: 20px; border-radius: 10px;">
        <!-- Left Column -->
            <div class="col-md-7" style="padding: 20px; border-radius: 10px;">
                <h1 class="display-5 text-white"><?php echo e($title); ?></h1>
                <p class="lead text-white"><?php echo e($leadText); ?></p>
                <hr class="my-4 text-dark">
                <p class="text-white"><?php echo e($description); ?></p>
            </div>
        <!-- Right Column -->
        <div class="col-md-5">
                <?php echo $__env->yieldContent('heroContent'); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/components/hero.blade.php ENDPATH**/ ?>