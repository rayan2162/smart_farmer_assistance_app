<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1558963235-eff20c9f7d99?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cGFkZHklMjBmaWVsZHxlbnwwfDB8MHx8fDI%3D'); ?>
        <?php $__env->slot('title', 'Edit & Update '); ?>
        <?php $__env->slot('leadText', 'Edit and update your crop information.'); ?>
        <?php $__env->slot('description', ' '); ?>
    
        <?php $__env->startSection('heroContent'); ?>
            
        <div class="col-md-8">
            <form action="<?php echo e(route('crop.update', $crop->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="name">Crop Name</label>
                    <div class="col-sm-8">
                        <input style="border: #4B6F44 solid" type="text" class="form-control" id="name" name="name" value="<?php echo e($crop->name); ?>" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="type">Crop Type</label>
                    <div class="col-sm-8">
                        <input style="border: #4B6F44 solid" type="text" class="form-control" id="type" name="type" value="<?php echo e($crop->type); ?>" required>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="planting_date">Planting Date</label>
                    <div class="col-sm-8">
                        <input style="border: #4B6F44 solid" type="date" class="form-control" id="planting_date" name="planting_date" value="<?php echo e($crop->planting_date); ?>" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="harvest_date">Harvest Date</label>
                    <div class="col-sm-8">
                        <input style="border: #4B6F44 solid" type="date" class="form-control" id="harvest_date" name="harvest_date" value="<?php echo e($crop->harvest_date); ?>">
                    </div>
                </div>
                
                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="quantity">Quantity</label>
                    <div class="col-sm-8">
                        <input style="border: #4B6F44 solid" type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($crop->quantity); ?>" required>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="location">Location</label>
                    <div class="col-sm-8">
                        <input style="border: #4B6F44 solid" type="text" class="form-control" id="location" name="location" value="<?php echo e($crop->location); ?>" required>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label style="font-size: 1.15em" class="col-sm-4 col-form-label text-white" for="notes">Notes</label>
                    <div class="col-sm-8">
                        <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo e($crop->notes); ?></textarea>
                    </div>
                </div>

                <br>

                <button type="submit" class="btn" style="background:#4B6F44; color:white">Update</button>
            </form>

            <form action="<?php echo e(route('crop.destroy', $crop->id)); ?>" method="POST" style="margin-top: 20px;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>

        </div>

        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerShortPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/crop/editCropPage.blade.php ENDPATH**/ ?>