<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1454789476662-53eb23ba5907?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8bmFzYSUyMHdlYXRoZXJ8ZW58MHx8MHx8fDA%3D'); ?>
        <?php $__env->slot('title', 'Stay Updated with the Latest Weather Forecasts'); ?>
        <?php $__env->slot('leadText', 'Get accurate and up-to-date weather information to plan your farming activities.'); ?>
        <?php $__env->slot('description', 'Our weather forecast service provides you with real-time updates on temperature, rain predictions, and more. Make informed decisions and optimize your farming operations with reliable weather data.'); ?>
    
        <?php $__env->startSection('heroContent'); ?>
        
        <div class="container mt-5">
            <h1 class="text-white">Today's Weather</h1>
            <div id="today-weather">
                <?php if(isset($todayWeather)): ?>
                    <h4 class="text-white">Temperature: <?php echo e($todayWeather['hourly']['temperature_2m'][0] ?? 'N/A'); ?>°C</p>
                    <h4 class="text-white">Rain: <?php echo e($todayWeather['hourly']['rain'][0] ?? 'N/A'); ?> mm</p>
                <?php else: ?>
                    <h4 class="text-white">No weather data available.</p>
                <?php endif; ?>
            </div>
    
            <div class="mt-5">
                <h2 class="text-white">Get Weather by Date</h2>
                <form action="<?php echo e(route('weather.fetch')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label style="color: white" for="date">Date</label>
                        <input type="date" class="form-control" id="date" name="date" min="<?php echo e(now()->format('Y-m-d')); ?>" required>
                    </div>
                    <button type="submit" class="btn" style="background-color:#4B6F44; color: white;">Get Weather</button>
                </form>
            </div>
    
            <div id="date-weather" class="mt-5">
                <?php if(isset($newWeatherData)): ?>
                    <h2 class="text-white">Weather on <?php echo e(request('date')); ?></h3>
                    <h4 class="text-white">Temperature: <?php echo e($newWeatherData['hourly']['temperature_2m'][0] ?? 'N/A'); ?>°C</p>
                    <p>Rain: <?php echo e($newWeatherData['hourly']['rain'][0] ?? 'N/A'); ?> mm</p>
                <?php endif; ?>
            </div>
        </div>

        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerShortPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/weather/weatherPage.blade.php ENDPATH**/ ?>