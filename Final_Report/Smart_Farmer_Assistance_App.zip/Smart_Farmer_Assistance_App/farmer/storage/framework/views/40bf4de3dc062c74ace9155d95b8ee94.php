<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h1 class="mb-4">Unapproved Users</h1>
    <?php if($users->isEmpty()): ?>
        <p>No unapproved users found.</p>
    <?php else: ?>
        <table class="table table-bordered"  style="border: #4B6F44 solid">
            <thead>
                <tr>
                    <th style="border: #4B6F44 solid">Name</th>
                    <th style="border: #4B6F44 solid">Email</th>
                    <th style="border: #4B6F44 solid">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td  style="border: #4B6F44 solid"><?php echo e($user->name); ?></td>
                        <td  style="border: #4B6F44 solid"><?php echo e($user->email); ?></td>
                        <td  style="border: #4B6F44 solid">
                            <form method="POST" action="<?php echo e(route('admin.users.approve', $user->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn" style="background-color: #4B6F44; color: white">Approve</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerShortPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/admin/users.blade.php ENDPATH**/ ?>