<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1626984232613-f20f15589bee?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'); ?>
        <?php $__env->slot('title', 'Stay Informed with Latest Notices'); ?>
        <?php $__env->slot('leadText', 'Keep up-to-date with important announcements and information.'); ?>
        <?php $__env->slot('description', 'Access and manage notices effectively for your farm operations.'); ?>
    
        <?php $__env->startSection('heroContent'); ?>
        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table mt-6" style="border: #4B6F44 solid">
    <thead class="thead" style="background:#4B6F44; color:white; font-weight:bolder">
        <tr>
            <th style="border: #4B6F44 solid" scope="col">Notice Title</th>
            <th style="border: #4B6F44 solid" scope="col">PDF File</th>
            <th style="border: #4B6F44 solid" scope="col">Publish Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border: #4B6F44 solid">
                <td style="border: #4B6F44 solid" ><?php echo e($notice->title); ?></td>
                <td><a href="<?php echo e(asset('storage/notices/' . $notice->file)); ?>" target="_blank"  style="border: #4B6F44 solid" >View PDF</a></td>
                <td  style="border: #4B6F44 solid" ><?php echo e($notice->publish_date); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerLongPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/notice/userNotice.blade.php ENDPATH**/ ?>