<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1457414104202-9d4b4908f285?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cGlsZSUyMG9mJTIwc2Fja3N8ZW58MHwwfDB8fHwy'); ?>
        <?php $__env->slot('title', 'Efficiently manage your crop storage'); ?>
        <?php $__env->slot('leadText', 'Ensure proper storage tracking to preserve crop quality and reduce spoilage.'); ?>
        <?php $__env->slot('description', 'By inventory management, streamline your crop management process and protect your harvest investment. '); ?>
    
        <?php $__env->startSection('heroContent'); ?>
            <?php echo $__env->make('silo.siloForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<table class="table mt-6" style="border: #4B6F44 solid">
    <thead class="thead" style="background:#4B6F44; color:white; font-weight:bolder">
        <tr>
            
            <th scope="col">Name</th>
            <th scope="col">Type</th>
            <th scope="col">Capacity (tons)</th>
            <th scope="col">Location</th>
            <th scope="col">Stored Material</th>
            <th scope="col">Notes</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $silos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $silo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border: #4B6F44 solid">
                
                <td><?php echo e($silo->name); ?></td>
                <td><?php echo e($silo->type); ?></td>
                <td><?php echo e($silo->capacity); ?></td>
                <td><?php echo e($silo->location); ?></td>
                <td><?php echo e($silo->material); ?></td>
                <td><?php echo e($silo->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('silo.edit', $silo->id)); ?>" class="btn btn-sm" style="background-color: #4B6F44; color: white">Edit</a>
                    <form action="<?php echo e(route('silo.destroy', $silo->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerLongPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/silo/siloPage.blade.php ENDPATH**/ ?>