




    <div style="background: #4B6F44; color: white; padding: 7px; bottom:0; width:100%; position:fixed">
        <p style="float: right"><a href="#" style="color: white;">Back to top</a></p>
        <p style="margin-bottom: 0;">&copy; 2024 Smart Farmer Assistant Application (Made with Laravel 10) <br> For 6th Semester Software Development Course.</p>
    </div><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/layouts/footerShortPage.blade.php ENDPATH**/ ?>