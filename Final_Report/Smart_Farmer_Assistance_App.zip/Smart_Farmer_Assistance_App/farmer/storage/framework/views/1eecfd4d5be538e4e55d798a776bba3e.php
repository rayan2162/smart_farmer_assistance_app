<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1441122456239-401e92b73c65?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'); ?>
        <?php $__env->slot('title', 'Enhance the health and performance of your livestock'); ?>
        <?php $__env->slot('leadText', 'Enhance the well-being and productivity of your livestock with our comprehensive management solutions.'); ?>
        <?php $__env->slot('description', 'Monitor health metrics, track feeding schedules with our applcation. With advanced analytics manage your livestock for maximum profitability.'); ?>
    
        <?php $__env->startSection('heroContent'); ?>
            <?php echo $__env->make('livestock.livestockForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<table class="table mt-6" style="border: #4B6F44 solid">
    <thead class="thead" style="background:#4B6F44; color:white; font-weight:bolder">
        <tr>
            <th scope="col">Animal Type</th>
            <th scope="col">Breed</th>
            <th scope="col">Quantity</th>
            <th scope="col">Age</th>
            <th scope="col">Gender</th>
            <th scope="col">Health Status</th>
            <th scope="col">Date Acquired</th>
            <th scope="col">Location</th>
            <th scope="col">Notes</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $livestocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livestock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border: #4B6F44 solid">
                <td><?php echo e($livestock->animal_type); ?></td>
                <td><?php echo e($livestock->breed); ?></td>
                <td><?php echo e($livestock->quantity); ?></td>
                <td><?php echo e($livestock->age); ?></td>
                <td><?php echo e($livestock->gender); ?></td>
                <td><?php echo e($livestock->health_status); ?></td>
                <td><?php echo e($livestock->date_acquired); ?></td>
                <td><?php echo e($livestock->location); ?></td>
                <td><?php echo e($livestock->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('livestock.edit', $livestock->id)); ?>" class="btn btn-sm" style="background-color: #4B6F44; color: white">Edit</a>
                    <form action="<?php echo e(route('livestock.destroy', $livestock->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerLongPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/livestock/livestockPage.blade.php ENDPATH**/ ?>