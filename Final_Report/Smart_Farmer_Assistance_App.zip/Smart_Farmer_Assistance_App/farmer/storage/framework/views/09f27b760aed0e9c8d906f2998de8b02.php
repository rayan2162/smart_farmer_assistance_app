<form >

  <div class="form-group">
    <label class="text-white" for="text ">Demo Title here</label>
    <input type="text" class="form-control" id="text" placeholder="Demo placeholder text here">
  </div>

  <div class="form-group">
    <label class="text-white" for="text ">Demo Title here</label>
    <input type="text" class="form-control" id="text" placeholder="Demo placeholder text here">
  </div>
  
  <div class="form-group">
    <label class="text-white" for="text ">Demo Title here</label>
    <input type="text" class="form-control" id="text" placeholder="Demo placeholder text here">
  </div>

  <div class="form-group">
    <label class="text-white" for="text ">Demo Title here</label>
    <input type="text" class="form-control" id="text" placeholder="Demo placeholder text here">
  </div>
      
    <br>

    <button type="submit" class="btn" style="background:#4B6F44; color:white">Submit</button>

  </form><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/layouts/demoForm.blade.php ENDPATH**/ ?>