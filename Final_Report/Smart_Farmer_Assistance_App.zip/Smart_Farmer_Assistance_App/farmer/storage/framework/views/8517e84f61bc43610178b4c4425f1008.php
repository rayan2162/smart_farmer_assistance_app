




<footer class="footer mt-auto py-3" style="background: #4B6F44; color: white;">
    <div class="container">
        <p style="float: right"><a href="#" style="color: white;">Back to top</a></p>
        <p style="margin-bottom: 0;">&copy; 2024 Smart Farmer Assistant Application (Made with Laravel 10) <br> For 6th Semester Software Development Course.</p>
    </div>
</footer>






<?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/layouts/footerLongPage.blade.php ENDPATH**/ ?>