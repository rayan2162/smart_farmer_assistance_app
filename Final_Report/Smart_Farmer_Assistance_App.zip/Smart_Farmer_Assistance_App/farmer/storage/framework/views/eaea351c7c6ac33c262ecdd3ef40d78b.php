

<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1558963235-eff20c9f7d99?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cGFkZHklMjBmaWVsZHxlbnwwfDB8MHx8fDI%3D'); ?>
        <?php $__env->slot('title', 'Maximize your farm\'s potential '); ?>
        <?php $__env->slot('leadText', 'Increase your farm\'s productivity with our comprehensive Agro Forestry management solutions.'); ?>
        <?php $__env->slot('description', 'From agro-forestry planning to harvest tracking, streamline your operations for increased productivity and profitability. Stay organized and informed and utilize resources. '); ?>
    
        <?php $__env->startSection('heroContent'); ?>
            <?php echo $__env->make('agroforestry.agroforestryForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    

<table class="table mt-6" style="border: #4B6F44 solid">
    <thead class="thead" style="background:#4B6F44; color:white; font-weight:bolder">
        <tr>
            
            <th scope="col">Name</th>
            <th scope="col">Type</th>
            <th scope="col">Planting Date</th>
            <th scope="col">Harvest Date</th>
            <th scope="col">Quantity</th>
            <th scope="col">Location</th>
            <th scope="col">Notes</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $agroforestries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agroforestry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border: #4B6F44 solid">
                
                <td><?php echo e($agroforestry->name); ?></td>
                <td><?php echo e($agroforestry->type); ?></td>
                <td><?php echo e($agroforestry->planting_date); ?></td>
                <td><?php echo e($agroforestry->harvest_date); ?></td>
                <td><?php echo e($agroforestry->quantity); ?></td>
                <td><?php echo e($agroforestry->location); ?></td>
                <td><?php echo e($agroforestry->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('agroforestry.edit', $agroforestry->id)); ?>" class="btn btn-sm" style="background-color: #4B6F44; color: white">Edit</a>
                    <form action="<?php echo e(route('agroforestry.destroy', $agroforestry->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerLongPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/agroforestry/agroforestryPage.blade.php ENDPATH**/ ?>