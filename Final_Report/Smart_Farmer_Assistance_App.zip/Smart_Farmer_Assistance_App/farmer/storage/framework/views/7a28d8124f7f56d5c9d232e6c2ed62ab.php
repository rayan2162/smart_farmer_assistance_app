<?php $__env->startSection('carousel'); ?>
    <?php $__env->startComponent('components.hero'); ?>
        <?php $__env->slot('backgroundImage', 'https://images.unsplash.com/photo-1651844848643-5969245142cc?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZmFybSUyMGVxdWlwbWVudHxlbnwwfHwwfHx8MA%3D%3D'); ?>
        <?php $__env->slot('title', 'Keep your farm running with equipment storage solutions'); ?>
        <?php $__env->slot('leadText', 'Keep your farm running smoothly with our reliable equipment storage solutions.'); ?>
        <?php $__env->slot('description', ' From tractors to implements, organize your valuable assets. With convenient storage tracking protect your equipment investment and optimize operational efficiency.'); ?>
    
        <?php $__env->startSection('heroContent'); ?>
            <?php echo $__env->make('equipment.equipmentForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<table class="table mt-6" style="border: #4B6F44 solid">
    <thead class="thead" style="background:#4B6F44; color:white; font-weight:bolder">
        <tr>
            
            <th scope="col">Name</th>
            <th scope="col">Type</th>
            <th scope="col">Manufacturer</th>
            <th scope="col">Purchase Date</th>
            <th scope="col">Cost</th>
            <th scope="col">Condition</th>
            <th scope="col">Location</th>
            <th scope="col">Notes</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border: #4B6F44 solid">
                
                <td><?php echo e($equipment->name); ?></td>
                <td><?php echo e($equipment->type); ?></td>
                <td><?php echo e($equipment->manufacturer); ?></td>
                <td><?php echo e($equipment->purchase_date); ?></td>
                <td>$<?php echo e(number_format($equipment->cost, 2)); ?></td>
                <td><?php echo e($equipment->condition); ?></td>
                <td><?php echo e($equipment->location); ?></td>
                <td><?php echo e($equipment->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('equipment.edit', $equipment->id)); ?>" class="btn btn-sm" style="background-color: #4B6F44; color: white">Edit</a>
                    <form action="<?php echo e(route('equipment.destroy', $equipment->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footerLongPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Smart_Farmer_Assistance_App\farmer\resources\views/equipment/equipmentPage.blade.php ENDPATH**/ ?>