<!DOCTYPE html>
<html>
<head>
    <title>Smart Farmer Assistant Application</title>
</head>
<body>
    <h2>Contact Us Message</h2>
    <p>Email: {{ $details['email'] }}</p>
    <p>Message: {{ $details['message'] }}</p>
</body>
</html>