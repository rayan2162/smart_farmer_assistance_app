<div class="jumbotron" style="background-image: url('https://images.unsplash.com/photo-1484759288640-783b22c95d54?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'); background-size: cover; background-position: center; height: 70vh;">
      <div style="background: rgba(0, 0, 0, 0.5); padding: 20px; border-radius: 10px;">
          <h1 class="display-5 text-white">Connect with us</h1>
          <p class="lead text-white">Want to learn? Any inquiries? Feel free to send email to learn more. </p>
          <hr class="my-4 text-white">
          <a class="btn btn-lg" href="/send-email" role="button" style="background:#4B6F44; color:white">Send an Email</a>
          </p>
      </div>
  </div>
