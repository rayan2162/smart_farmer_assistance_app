{{-- FOOTER SHORT PAGE --}}

{{-- This footer should be used on pages if the pages 
does have content covering 100% or full one page.  --}}


<footer class="footer mt-auto py-3" style="background: #4B6F44; color: white;">
    <div class="container">
        <p style="float: right"><a href="#" style="color: white;">Back to top</a></p>
        <p style="margin-bottom: 0;">&copy; 2024 Smart Farmer Assistant Application (Made with Laravel 10) <br> For 6th Semester Software Development Course.</p>
    </div>
</footer>






