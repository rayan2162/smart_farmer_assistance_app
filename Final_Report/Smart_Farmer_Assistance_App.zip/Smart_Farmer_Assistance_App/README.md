# Smart_Farmer_Assistance_App
Software Developement course (6th semester)'s project.
